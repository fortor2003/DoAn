create trigger RAP_ID_TRG
    before insert
    on RAP
    for each row
begin
            if :new.ID is null then
                select RAP_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

