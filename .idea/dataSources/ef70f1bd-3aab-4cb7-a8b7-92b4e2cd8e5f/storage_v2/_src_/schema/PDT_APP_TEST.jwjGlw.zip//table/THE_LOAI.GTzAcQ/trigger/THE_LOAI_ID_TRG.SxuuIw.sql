create trigger THE_LOAI_ID_TRG
    before insert
    on THE_LOAI
    for each row
begin
            if :new.ID is null then
                select THE_LOAI_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

