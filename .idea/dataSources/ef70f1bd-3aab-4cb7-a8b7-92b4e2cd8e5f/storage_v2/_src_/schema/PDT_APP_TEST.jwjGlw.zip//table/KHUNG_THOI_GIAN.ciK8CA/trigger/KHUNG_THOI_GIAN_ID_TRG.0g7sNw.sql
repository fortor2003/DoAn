create trigger KHUNG_THOI_GIAN_ID_TRG
    before insert
    on KHUNG_THOI_GIAN
    for each row
begin
            if :new.ID is null then
                select KHUNG_THOI_GIAN_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

