create trigger PHONG_CHIEU_ID_TRG
    before insert
    on PHONG_CHIEU
    for each row
begin
            if :new.ID is null then
                select PHONG_CHIEU_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

