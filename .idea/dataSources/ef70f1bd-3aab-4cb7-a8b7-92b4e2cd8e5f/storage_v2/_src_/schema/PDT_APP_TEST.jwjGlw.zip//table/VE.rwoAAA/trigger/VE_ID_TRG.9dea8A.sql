create trigger VE_ID_TRG
    before insert
    on VE
    for each row
begin
            if :new.ID is null then
                select VE_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

